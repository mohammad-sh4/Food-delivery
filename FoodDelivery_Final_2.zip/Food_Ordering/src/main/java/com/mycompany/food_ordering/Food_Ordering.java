/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.food_ordering;

/**
 *
 * @author mohamamd
 */
public class Food_Ordering {

    public static void main(String[] args) {
       new Login().setVisible(true);
    }
}
